from django.shortcuts import render, redirect
from .models import User, Secret
from django.db.models import Count
from django.contrib import messages
import bcrypt



def index(request):


	return render(request, 'dojo_secrets_app/index.html')

def currentUser(request):		
	user = User.objects.get(id=request.session['user_id'])

	return user

def secrets(request):
	if 'user_id' in request.session:
		
		user = currentUser(request)



		context = {
		'user': user,
		'secrets': Secret.objects.all().annotate(num_likes = Count('liked_by')).order_by('-created_at')[:5],
		'created_at': Secret.objects.all()		
		}

		return render(request, 'dojo_secrets_app/secrets.html', context)

	return redirect('/')

def allsecrets(request):
	if 'user_id' in request.session:

		# user = currentUser(request)

		context = {
		'secrets': Secret.objects.annotate(num_likes = Count('liked_by')).order_by('-num_likes')
		 }
		return render(request, 'dojo_secrets_app/allsecrets.html', context)

def post(request):
	if request.method == 'POST':

		user = currentUser(request)
		
		Secret.objects.create(secret=request.POST['secret'], user=user)
		print "!!!!!!!!!!!!!!!!!!!!!!!!!!!"
	return redirect ('/secrets')

def delete(request, id):

	secret = Secret.objects.get(id=id)
	secret.delete()

	return redirect('/secrets')

def like(request, id):
	
	user = currentUser(request)

	secret = Secret.objects.get(id=id)	

	user.likes.add(secret)

	likes = secret.liked_by.all()

	for like in likes:
		print like.first_name	

	return redirect('/secrets')

def register(request):
	if request.method == 'POST':
		


		errors = User.objects.validateRegistration(request.POST)

		if not errors:
			user = User.objects.createUser(request.POST)

			request.session['user_id'] = user.id

			return redirect('/secrets')

		for error in errors:
			messages.error(request, error)
		print errors

	return redirect('/')

def login(request):
	if request.method == 'POST':
		errors = User.objects.validateLogin(request.POST)

		if not errors:
			user = User.objects.filter(email = request.POST['email']).first()

			if user:
				password = str(request.POST['password'])
				user_password = str(user.password)

				hashed_pw = bcrypt.hashpw(password, user_password)

				if hashed_pw == user.password:
					request.session['user_id'] = user.id
					# request.session['first_name'] = first_name
					
					return redirect('/secrets')

			errors.append('Invalid account information.')
		
		for error in errors:
			messages.error(request, error)

		return redirect('/')

		print request.session['user_id']

		print errors


def logout(request):
	if 'user_id' in request.session:
		request.session.pop('user_id')

	return redirect('/')