# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class FriendAppConfig(AppConfig):
    name = 'friend_app'
